(function() {
  const DEFAULT_RPC_URL = typeof ARIA2_DEFAULT_RPC_URL !== 'undefined'
    ? ARIA2_DEFAULT_RPC_URL
    : 'http://localhost:6800/jsonrpc';
  const DEFAULT_FILTER_EXTENSIONS = typeof ARIA2_DEFAULT_FILTER_EXTENSIONS !== 'undefined'
    ? ARIA2_DEFAULT_FILTER_EXTENSIONS
    : [];
  const DEFAULT_SAFE_MODE_HOSTS = typeof ARIA2_DEFAULT_SAFE_MODE_HOSTS !== 'undefined'
    ? ARIA2_DEFAULT_SAFE_MODE_HOSTS
    : [
        'gofile.io', '1fichier.com', 'pixeldrain.com', 'mediafire.com',
        'mega.nz', 'ranoz.net', 'datanodes.to', 'bowfile.com',
        'dl.free.fr', 'swisstransfer.com', 'freedlink.me', 'fileditch.com',
        'uploadnow.io', 'wdho.ru', 'mixdrop.', 'chomikuj.pl',
        'vikingfile.com', 'dayuploads.com', 'downmediaload.com', 'hexload.com',
        '1cloudfile.com', 'usersdrive.com', 'megaup.net', 'clicknupload.org',
        'dailyuploads.net', 'rapidgator.net', 'nitroflare.com', 'filebin.net',
        'oshi.at',
      ];

  function storageGet(keys) {
    return new Promise((resolve) => {
      chrome.storage.local.get(keys, resolve);
    });
  }

  function storageSet(values) {
    return new Promise((resolve) => {
      chrome.storage.local.set(values, resolve);
    });
  }

  async function getConfig() {
    const result = await storageGet([
      'aria2_rpc_url',
      'aria2_rpc_secret',
      'aria2_default_download_path',
      'aria2_hijack_downloads',
      'aria2_safe_mode',
      'aria2_safe_mode_hosts',
      'aria2_completion_notifications',
      'aria2_filter_extensions',
      'aria2_theme',
    ]);
    return {
      rpcUrl: result.aria2_rpc_url || DEFAULT_RPC_URL,
      secret: result.aria2_rpc_secret || '',
      downloadPath: result.aria2_default_download_path || '',
      hijackDownloads: result.aria2_hijack_downloads || false,
      safeMode: result.aria2_safe_mode !== false,
      safeModeHosts: result.aria2_safe_mode_hosts || [...DEFAULT_SAFE_MODE_HOSTS],
      completionNotifications: result.aria2_completion_notifications !== false,
      filterExtensions: result.aria2_filter_extensions || [],
      theme: result.aria2_theme || 'original',
    };
  }

  async function saveConfig(config) {
    return storageSet({
      aria2_rpc_url: config.rpcUrl,
      aria2_rpc_secret: config.secret,
      aria2_default_download_path: config.downloadPath,
      aria2_hijack_downloads: config.hijackDownloads,
      aria2_safe_mode: config.safeMode,
      aria2_safe_mode_hosts: config.safeModeHosts,
      aria2_completion_notifications: config.completionNotifications,
      aria2_filter_extensions: config.filterExtensions,
      aria2_theme: config.theme || 'original',
    });
  }

  async function setHijackStatus(enabled) {
    return storageSet({ aria2_hijack_downloads: enabled });
  }

  const CUSTOM_THEMES_KEY = typeof ARIA2_CUSTOM_THEMES_KEY !== 'undefined'
    ? ARIA2_CUSTOM_THEMES_KEY
    : 'aria2_custom_themes';

  function hexToRgb(hex) {
    const val = parseInt(hex.replace('#', ''), 16);
    return { r: (val >> 16) & 255, g: (val >> 8) & 255, b: val & 255 };
  }

  function lightenColor(r, g, b, amount) {
    const a = Math.round(255 * amount);
    return {
      r: Math.min(255, r + a),
      g: Math.min(255, g + a),
      b: Math.min(255, b + a),
    };
  }

  function computeCustomThemeVars(theme) {
    const ar = hexToRgb(theme.accent);
    const ab = hexToRgb(theme.amber);
    const gr = hexToRgb(theme.green);
    const bright = lightenColor(ar.r, ar.g, ar.b, 0.06);
    const brightHex = '#' + [bright.r, bright.g, bright.b].map(x => x.toString(16).padStart(2, '0')).join('');

    const accentRGB = `${ar.r}, ${ar.g}, ${ar.b}`;
    const amberRGB = `${ab.r}, ${ab.g}, ${ab.b}`;
    const greenRGB = `${gr.r}, ${gr.g}, ${gr.b}`;
    const gray300RGB = `112, 112, 112`;

    return {
      '--accent': theme.accent,
      '--accent-rgb': accentRGB,
      '--accent-bright': brightHex,
      '--accent-dim': `rgba(${accentRGB}, 0.08)`,
      '--accent-glow': `rgba(${accentRGB}, 0.25)`,
      '--accent-glow-soft': `rgba(${accentRGB}, 0.15)`,
      '--accent-glow-mid': `rgba(${accentRGB}, 0.35)`,
      '--accent-glow-hard': `rgba(${accentRGB}, 0.45)`,
      '--red': theme.accent,
      '--red-dim': `rgba(${accentRGB}, 0.08)`,
      '--amber': theme.amber,
      '--amber-rgb': amberRGB,
      '--amber-dim': `rgba(${amberRGB}, 0.08)`,
      '--amber-glow': `rgba(${amberRGB}, 0.3)`,
      '--green': theme.green,
      '--green-rgb': greenRGB,
      '--green-dim': `rgba(${greenRGB}, 0.08)`,
      '--green-glow': `rgba(${greenRGB}, 0.3)`,
      '--gray-300-rgb': gray300RGB,
    };
  }

  async function getCustomThemes() {
    const result = await storageGet(CUSTOM_THEMES_KEY);
    return result[CUSTOM_THEMES_KEY] || [];
  }

  async function saveCustomThemes(themes) {
    return storageSet({ [CUSTOM_THEMES_KEY]: themes });
  }

  async function getAllThemes() {
    const builtIn = typeof ARIA2_THEMES !== 'undefined'
      ? ARIA2_THEMES
      : [{ id: 'original', name: 'Original', accent: '#ff1a1a' }];
    const custom = await getCustomThemes();
    const customMapped = custom.map(t => ({
      id: 'custom:' + t.id,
      name: '✦ ' + t.name,
      accent: t.accent,
      _custom: true,
    }));
    return [...builtIn, ...customMapped];
  }

  async function applyTheme(theme) {
    if (!theme) {
      const result = await storageGet('aria2_theme');
      theme = result.aria2_theme || 'original';
    }
    const el = document.documentElement;
    el.removeAttribute('data-theme');
    if (theme && theme.startsWith('custom:')) {
      const customId = theme.slice('custom:'.length);
      const customs = await getCustomThemes();
      const ct = customs.find(t => t.id === customId);
      if (ct) {
        const vars = computeCustomThemeVars(ct);
        for (const [key, val] of Object.entries(vars)) {
          el.style.setProperty(key, val);
        }
      } else {
        el.removeAttribute('style');
        await storageSet({ aria2_theme: 'original' });
      }
    } else {
      el.removeAttribute('style');
      if (theme && theme !== 'original') {
        el.setAttribute('data-theme', theme);
      }
    }
  }

  async function callAria2(method, params = []) {
    const config = await getConfig();
    const secretToken = config.secret ? [`token:${config.secret}`] : [];
    const body = {
      jsonrpc: '2.0',
      id: crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(),
      method,
      params: [...secretToken, ...params],
    };

    const response = await fetch(config.rpcUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });

    const parsed = await response.json();
    if (parsed.error) {
      throw new Error(parsed.error.message || 'aria2 RPC error');
    }
    return parsed.result;
  }

  async function testConnectionWithParams(rpcUrl, secret) {
    const secretToken = secret ? [`token:${secret}`] : [];
    const body = {
      jsonrpc: '2.0',
      id: crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(),
      method: 'aria2.getVersion',
      params: secretToken,
    };
    const response = await fetch(rpcUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    const parsed = await response.json();
    if (parsed.error) {
      throw new Error(parsed.error.message || 'aria2 RPC error');
    }
    return parsed.result;
  }

  async function getAria2Status() {
    const tellKeys = [
      'gid', 'status', 'totalLength', 'completedLength',
      'downloadSpeed', 'uploadSpeed', 'files', 'connections',
      'completedTime',
    ];
    const [globalStat, active, waiting, stopped] = await Promise.all([
      callAria2('aria2.getGlobalStat'),
      callAria2('aria2.tellActive', [tellKeys]),
      callAria2('aria2.tellWaiting', [0, 100, tellKeys]),
      callAria2('aria2.tellStopped', [0, 100, tellKeys]),
    ]);
    return { globalStat, active, waiting, stopped };
  }

  function getFileName(download) {
    if (download.files && download.files.length > 0) {
      const path = download.files[0].path;
      return path.split('/').pop() || path || download.gid;
    }
    return download.gid;
  }

  function formatBytes(bytes) {
    const n = parseInt(bytes, 10);
    if (isNaN(n) || n === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.min(Math.floor(Math.log(n) / Math.log(k)), sizes.length - 1);
    return parseFloat((n / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  }

  function formatSpeed(bytesPerSecond) {
    return formatBytes(parseInt(bytesPerSecond, 10) || 0) + '/s';
  }

  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = String(text ?? '');
    return div.innerHTML;
  }

  window.Aria2Shared = {
    DEFAULT_RPC_URL,
    DEFAULT_SAFE_MODE_HOSTS,
    DEFAULT_FILTER_EXTENSIONS,
    getConfig,
    saveConfig,
    setHijackStatus,
    applyTheme,
    callAria2,
    testConnectionWithParams,
    getAria2Status,
    getFileName,
    formatBytes,
    formatSpeed,
    escapeHtml,
    getCustomThemes,
    saveCustomThemes,
    getAllThemes,
    hexToRgb,
    computeCustomThemeVars,
  };
})();
