# Aria2 Dashboard — Lit + Vite + TypeScript Porting Log

## Stack

- **UI framework**: Lit 3 (Web Components with reactive properties, `html` tagged templates, **light DOM** for initial port — `createRenderRoot() { return this; }`)
- **Build tool**: Vite 5 (multi-entry build for popup/options/full HTML pages, `vite-plugin-static-copy` for manifest/icons/background/content)
- **Language**: TypeScript (strict mode, `@types/chrome` for extension API types, `experimentalDecorators` + `useDefineForClassFields: false` for Lit)
- **CSS**: CSS custom properties (unchanged — `theme.css` tokens work in light DOM). Global `theme.css` + `shared.css` referenced from HTML entry points, Vite bundles them.
- **Rendering approach**: Light DOM (no Shadow DOM) — `createRenderRoot() { return this; }` in all components. This preserves all existing global CSS without modification. Can gradually switch to Shadow DOM later as styles are split into per-component `static styles`.
- **Unchanged files**: `content.js` (vanilla JS, injected into every page — Lit runtime too heavy), `background.js` (vanilla JS, no DOM)

## Directory Structure

```
src/
├── entries/           # HTML entry points for Vite
│   ├── popup.html
│   ├── options.html
│   └── full.html
├── components/        # Lit Web Components
│   ├── aria2-logo.ts        # shared dot-matrix SVG logo
│   ├── aria2-chip-list.ts   # reusable chip list (hosts, filters, theme swatches)
│   ├── aria2-download-row.ts
│   ├── aria2-popup.ts
│   ├── aria2-options.ts
│   ├── aria2-theme-editor.ts
│   ├── aria2-dashboard.ts
├── lib/               # Shared TypeScript modules (no DOM)
│   ├── constants.ts
│   ├── shared.ts       # getConfig, saveConfig, callAria2, formatBytes, etc.
│   ├── theme.ts        # applyTheme, computeCustomThemeVars, getAllThemes
├── styles/
│   ├── theme.css       # unchanged — CSS token definitions
│   ├── shared.css      # structural styles shared across components (btn, input, toggle, etc.)
├── background.js       # stays vanilla JS for now (service worker, no DOM)
├── content.js          # stays vanilla JS (injected into pages)
```

## Porting Strategy

1. Create infrastructure (package.json, vite.config.ts, tsconfig.json) — **DONE**
2. Port foundation modules (constants.ts, shared.ts, theme.ts) — **DONE**
3. Create first Lit component (aria2-logo) — **DONE** (light DOM, uses global CSS `.logo` class)
4. Create reusable component (aria2-chip-list) — **DONE** (light DOM, uses existing `.host-chip`, `.theme-chip-*` classes from shared.css)
5. Create stub view components (aria2-popup, aria2-options, aria2-dashboard) — **DONE** (placeholder renders)
6. Create HTML entry points — **DONE**
7. Create manifest.lit.json for Lit build — **DONE**
8. Verify Vite build passes (TypeScript + Chrome build) — **DONE** ✓
9. Port full popup view — **DONE** ✓ (aria2-popup.ts: hijack toggle, compact stats, download list with active/waiting/recent, polling, action handlers)
10. Port full options + theme editor view — **DONE** ✓ (aria2-options.ts + aria2-theme-editor.ts: general/safe-mode/filters/themes tabs, theme editor, storage listeners)
11. Port full dashboard view — **DONE** ✓ (aria2-dashboard.ts: sidebar stats, search bar, active/waiting/stopped tabs, download list, settings toggle, add download, polling)
12. Firefox build verification — **DONE** ✓ (both Chrome and Firefox builds pass)

## Change Log

### Step 1: Infrastructure setup
- Created `package.json` with `lit`, `vite`, `typescript`, `@types/chrome`, `@types/node`, `vite-plugin-static-copy`
- Created `vite.config.ts` with `base: ""` (relative paths for extensions), multi-entry build, static copy for manifest/icons/background/content
- Created `tsconfig.json` with strict mode, `experimentalDecorators`, `useDefineForClassFields: false` (required for Lit decorators). Removed deprecated `baseUrl`/`paths` (not used — all imports are relative). Added `node_modules/` to `.gitignore`.
- `manifest.lit.json` created for Lit build (references `src/entries/popup.html` etc.), Vite copies it as `manifest.json` to dist
- Build command: `npm run build:chrome` → `dist/chrome/`, `npm run build:firefox` → `dist/firefox/`

### Step 2: Foundation modules (constants.ts, shared.ts, theme.ts)
- `src/lib/constants.ts`: Added TypeScript interfaces (`BuiltInTheme`, `CustomTheme`, `ThemeId` type union), exported as ES module. No `window.ARIA2_THEMES` global — components import directly.
- `src/lib/shared.ts`: All utility functions (`getConfig`, `saveConfig`, `callAria2`, `getAria2Status`, `formatBytes`, `formatSpeed`, `escapeHtml`) exported as ES module. Added TypeScript interfaces for `Aria2Config`, `Aria2Download`, `Aria2GlobalStat`, `Aria2Status`.
- `src/lib/theme.ts`: Theme engine extracted from shared.js — `applyTheme`, `computeCustomThemeVars`, `getAllThemes`, `getCustomThemes`, `saveCustomThemes` all exported. Added `CustomThemeVars` interface. Handles deleted custom themes by resetting `aria2_theme` to `'original'` in storage.
- `src/styles/theme.css`: Copied from `src/theme.css` (unchanged). Vite bundles it via HTML `<link>` references.
- `src/styles/shared.css`: Copied from `src/style.css` (unchanged). Will be gradually split into component styles as Shadow DOM is adopted.

### Step 3: aria2-logo component
- `src/components/aria2-logo.ts`: Lit Web Component, light DOM (`createRenderRoot() { return this; }`). Uses `@property({ type: Number }) size = 28`. Renders the dot-matrix SVG inside a `<div class="logo">` wrapper — matches existing CSS `.logo` class. Registered as `<aria2-logo>`.
- Eliminates 3 copies of the SVG logo that were in popup.js, full.js, and options.js.

### Step 4: aria2-chip-list component
- `src/components/aria2-chip-list.ts`: Lit Web Component, light DOM. Uses `@property({ type: Array }) chips: ChipData[]` and `@property({ type: String }) emptyText`. Renders using existing CSS classes (`host-chip`, `theme-chip-swatch`, `host-chip-remove`, `theme-chip-edit`, `theme-chip-delete`, `empty-hosts`). Dispatches `chip-delete` and `chip-edit` CustomEvents with `{ detail: { index } }`.
- `ChipData` interface: `{ label, accent?, deletable?, editable? }`.
- Will be reused for safe-mode hosts, file extension filters, and custom theme swatches — eliminating ~80 lines of duplicated render/delete logic from options.js.

### Step 5: Stub view components
- `src/components/aria2-popup.ts`: Light DOM, placeholder render with `<aria2-logo>` + text. Calls `applyTheme()` in `connectedCallback()`.
- `src/components/aria2-options.ts`: Light DOM, placeholder render.
- `src/components/aria2-dashboard.ts`: Light DOM, placeholder render.
- All three mount themselves into `#root` on script load (same pattern as original popup.js/options.js/full.js).

### Step 6: HTML entry points + manifest
- `src/entries/popup.html`, `src/entries/options.html`, `src/entries/full.html`: Each loads `<link>` for theme.css + shared.css, `<script type="module">` for the respective Lit component.
- `manifest.lit.json`: Updated paths — `default_popup: "src/entries/popup.html"`, `options_page: "src/entries/options.html"`. Background and content script paths unchanged.
- Vite build verified: `tsc --noEmit` passes, `vite build --mode chrome` produces working `dist/chrome/` with all files.

### Build verification
- `npm run typecheck` (tsc --noEmit) — passes ✓
- `npm run build:chrome` (vite build) — passes ✓
- Output: 29 modules transformed, HTML + JS + CSS + manifest + icons + background.js + content.js all present

### Step 9-11: Ported full application views
- `src/components/aria2-download-row.ts`: Shared download row component supporting compact (popup) and full (dashboard) modes. Renders filename, status badge, progress dots, action buttons. Dispatches `download-action` CustomEvent with `{ action, gid }`.
- `src/components/aria2-popup.ts`: Full popup view with header (logo, hijack toggle, settings button), compact stats bar, download list (active + waiting + recent completed), connection status footer, polling (1s fast / 2.5s idle / 5s error). Handles pause/resume/stop/remove/move actions.
- `src/components/aria2-options.ts`: Full options page with general (RPC URL, secret, download path, notifications, hijack, theme, quick actions), safe-mode (toggle, hosts list with add/remove), filters (extension filters with add/remove), themes (built-in list, custom list with create/edit/delete, embedded theme editor). Storage change listeners for real-time sync. Integrates with dashboard via `FullApp()` for embedded mode.
- `src/components/aria2-theme-editor.ts`: Standalone theme editor component with name input, accent/amber/green color pickers + hex inputs, preview dots, save/cancel buttons. Dispatches `theme-save` and `theme-cancel` events.
- `src/lib/shared.ts`: Fixed — exported `Aria2Download` and `Aria2GlobalStat` interfaces for use in components.
- Build output: 33 modules transformed (was 29), all builds pass.